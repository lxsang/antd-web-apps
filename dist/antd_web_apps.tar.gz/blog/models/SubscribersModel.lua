BaseModel:subclass("SubscribersModel",{
    registry = {},
    name = "subscribers",
    fields = {
        name =	"TEXT",
	    email =	"TEXT"
    }
})