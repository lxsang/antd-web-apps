BaseModel:subclass("CategoryModel",{
    registry = {},
    name = "cv_cat",
    fields = {
        publish = "NUMERIC",
	    name =	"TEXT",
	    pid	= "NUMERIC"
    }
})