BaseModel:subclass("UserModel",{
    registry = {},
    name = "user",
    fields = {
        address = "TEXT",
	    Phone	= "TEXT",
	    shortbiblio	= "TEXT",
	    fullname = "TEXT",
	    email = "TEXT",
	    url = "TEXT"
    }
})