BaseController:subclass("TocController")

function TocController:index(...)
    return true
end