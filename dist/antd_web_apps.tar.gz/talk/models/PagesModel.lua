BaseModel:subclass("PagesModel",
                   {registry = {}, name = "pages", fields = {uri = "TEXT"}})
